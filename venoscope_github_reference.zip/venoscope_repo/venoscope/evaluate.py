import argparse,json
import numpy as np
import torch
from .model import VenoUNet
from .data import NPZDataset
from .metrics import binary_metrics

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data',required=True);ap.add_argument('--checkpoint',required=True)
    args=ap.parse_args()
    device='cuda' if torch.cuda.is_available() else 'cpu'
    ckpt=torch.load(args.checkpoint,map_location='cpu',weights_only=True)
    model=VenoUNet(base=ckpt['base']).to(device)
    model.load_state_dict(ckpt['state_dict']);model.eval()
    dataset=NPZDataset(args.data);results=[]
    with torch.no_grad():
        for i in range(len(dataset)):
            x,y=dataset[i]
            probs=torch.sigmoid(model(x[None].to(device)))[0].cpu().numpy()
            results.append({'sample':dataset.files[i].name,
                            'leg':binary_metrics(probs[0],y[0].numpy()),
                            'pulse':binary_metrics(probs[1],y[1].numpy())})
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
