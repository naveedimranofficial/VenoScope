import torch
from torch import nn
import torch.nn.functional as F

class ConvBlock(nn.Module):
    def __init__(self, cin, cout):
        super().__init__()
        self.net = nn.Sequential(nn.Conv3d(cin, cout, 3, padding=1), nn.InstanceNorm3d(cout), nn.ReLU(inplace=True),
                                 nn.Conv3d(cout, cout, 3, padding=1), nn.InstanceNorm3d(cout), nn.ReLU(inplace=True))
    def forward(self, x): return self.net(x)

class VenoUNet(nn.Module):
    """Five-channel 3D U-Net with two independent binary-mask logits.

    Base width defaults to 32. Exact depth and parameter count must be
    checked against the final manuscript before claiming equivalence.
    """
    def __init__(self, in_channels=5, base=32, out_channels=2):
        super().__init__()
        self.enc1=ConvBlock(in_channels,base)
        self.enc2=ConvBlock(base,base*2)
        self.enc3=ConvBlock(base*2,base*4)
        self.bottleneck=ConvBlock(base*4,base*8)
        self.pool=nn.MaxPool3d(2)
        self.up3=nn.ConvTranspose3d(base*8,base*4,2,stride=2)
        self.dec3=ConvBlock(base*8,base*4)
        self.up2=nn.ConvTranspose3d(base*4,base*2,2,stride=2)
        self.dec2=ConvBlock(base*4,base*2)
        self.up1=nn.ConvTranspose3d(base*2,base,2,stride=2)
        self.dec1=ConvBlock(base*2,base)
        self.head=nn.Conv3d(base,out_channels,1)
    def forward(self,x):
        a=self.enc1(x);b=self.enc2(self.pool(a));c=self.enc3(self.pool(b))
        d=self.bottleneck(self.pool(c))
        def merge(u,skip):
            if u.shape[2:]!=skip.shape[2:]: u=F.interpolate(u,size=skip.shape[2:],mode='trilinear',align_corners=False)
            return torch.cat([u,skip],dim=1)
        d=self.dec3(merge(self.up3(d),c))
        d=self.dec2(merge(self.up2(d),b))
        d=self.dec1(merge(self.up1(d),a))
        return self.head(d)
