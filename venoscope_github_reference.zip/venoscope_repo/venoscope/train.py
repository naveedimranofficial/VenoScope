import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from .model import VenoUNet
from .data import NPZDataset

def loss_fn(logits, target):
    bce=torch.nn.functional.binary_cross_entropy_with_logits(logits,target)
    p=torch.sigmoid(logits)
    dims=(0,2,3,4)
    dice=1-(2*(p*target).sum(dims)+1)/((p+target).sum(dims)+1)
    return bce+dice.mean()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--train',required=True)
    ap.add_argument('--val',required=True)
    ap.add_argument('--epochs',type=int,default=10)
    ap.add_argument('--batch-size',type=int,default=1)
    ap.add_argument('--base',type=int,default=32)
    ap.add_argument('--lr',type=float,default=1e-4)
    ap.add_argument('--out',default='outputs/model.pt')
    args=ap.parse_args()
    torch.manual_seed(42)
    device='cuda' if torch.cuda.is_available() else 'cpu'
    train=DataLoader(NPZDataset(args.train),batch_size=args.batch_size,shuffle=True)
    val=DataLoader(NPZDataset(args.val),batch_size=1)
    model=VenoUNet(base=args.base).to(device)
    opt=torch.optim.Adam(model.parameters(),lr=args.lr)
    best=float('inf')
    for epoch in range(args.epochs):
        model.train();losses=[]
        for x,y in train:
            x=x.to(device);y=y.to(device)
            opt.zero_grad();loss=loss_fn(model(x),y);loss.backward();opt.step()
            losses.append(loss.item())
        model.eval();v=[]
        with torch.no_grad():
            for x,y in val: v.append(loss_fn(model(x.to(device)),y.to(device)).item())
        score=sum(v)/len(v)
        print(f'epoch={epoch+1} train_loss={sum(losses)/len(losses):.4f} val_loss={score:.4f}')
        if score<best:
            best=score;Path(args.out).parent.mkdir(parents=True,exist_ok=True)
            torch.save({'state_dict':model.state_dict(),'base':args.base,'epoch':epoch+1},args.out)
if __name__=='__main__': main()
