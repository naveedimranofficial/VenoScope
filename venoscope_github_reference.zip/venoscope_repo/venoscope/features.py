"""Reference feature extraction; not a validated reproduction of original radar pipeline."""
import numpy as np
from scipy.signal import butter, sosfiltfilt, hilbert

def bandpass(x, fs, low=0.8, high=2.5):
    if not (0 < low < high < fs / 2):
        raise ValueError("Require 0 < low < high < fs/2")
    sos = butter(3, [low, high], btype="bandpass", fs=fs, output="sos")
    return sosfiltfilt(sos, x, axis=-1)

def build_features(volume, pulse, fs, low=0.8, high=2.5, window=32):
    """Return (5,R,A,T) float32: energy, PSMF, DPFC, PSCM, TVI.

    volume: real slow-time motion signal (R,A,T); pulse: aligned (T,).
    Feature definitions are operational approximations requiring validation against
    the authors' exact experimental definitions and calibration.
    """
    v = np.asarray(volume, dtype=np.float64)
    ref = np.asarray(pulse, dtype=np.float64)
    if v.ndim != 3 or ref.shape != (v.shape[-1],):
        raise ValueError("Expected volume (R,A,T) and pulse (T,)")
    if v.shape[-1] < max(24, window):
        raise ValueError("Time dimension too short")
    x = bandpass(v, fs, low, high)
    g = bandpass(ref, fs, low, high)
    eps = 1e-8
    energy = np.sqrt(np.mean(x*x, axis=-1, keepdims=True))
    energy = np.broadcast_to(energy, x.shape)
    # Normalized, zero-lag pulse reference similarity (proxy for PSMF).
    xc = x - x.mean(axis=-1, keepdims=True)
    gc = g - g.mean()
    corr = np.abs(np.sum(xc * gc, axis=-1, keepdims=True)) / (
        np.linalg.norm(xc, axis=-1, keepdims=True) * np.linalg.norm(gc) + eps)
    psmf = np.broadcast_to(corr, x.shape)
    # Dominant pulse-band frequency consistency with wearable reference.
    freq = np.fft.rfftfreq(x.shape[-1], d=1/fs)
    band = (freq >= low) & (freq <= high)
    if not np.any(band):
        raise ValueError("No FFT bins in pulse band")
    power = np.abs(np.fft.rfft(x, axis=-1))[..., band]
    fvox = freq[band][np.argmax(power, axis=-1)]
    fref = freq[band][np.argmax(np.abs(np.fft.rfft(g))[band])]
    dpfc = np.broadcast_to(np.exp(-np.abs(fvox-fref)[..., None]/0.25), x.shape)
    # Neighborhood phase-coherence proxy.
    phase = np.angle(hilbert(x, axis=-1))
    z = np.exp(1j*phase)
    neighbors = [np.roll(z, 1, 0), np.roll(z, -1, 0),
                 np.roll(z, 1, 1), np.roll(z, -1, 1)]
    pscm = np.abs(np.mean(np.stack(neighbors), axis=0) * np.conj(z))
    # Sliding-window RMS variability, broadcast to each window's time indices.
    tvi = np.zeros_like(x)
    rms_windows = []
    starts = list(range(0, x.shape[-1]-window+1, max(1,window//2)))
    for start in starts:
        rms_windows.append(np.sqrt(np.mean(x[..., start:start+window]**2, axis=-1)))
    rms_windows = np.stack(rms_windows, axis=-1)
    variability = np.std(rms_windows, axis=-1) / (np.mean(rms_windows, axis=-1)+eps)
    tvi[:] = variability[..., None]
    feats = np.stack([energy, psmf, dpfc, pscm, tvi], axis=0)
    # Per-channel scaling (sample-specific, not fitted on test cohort).
    for c in range(feats.shape[0]):
        zc = feats[c]
        lo, hi = np.percentile(zc, [1, 99])
        feats[c] = np.clip((zc-lo)/(hi-lo+eps), 0, 1)
    return feats.astype(np.float32)
