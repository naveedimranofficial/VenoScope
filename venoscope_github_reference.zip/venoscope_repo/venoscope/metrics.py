import numpy as np

def binary_metrics(pred, target, threshold=0.5):
    p=np.asarray(pred)>=threshold
    y=np.asarray(target).astype(bool)
    if p.shape!=y.shape: raise ValueError("shape mismatch")
    tp=np.logical_and(p,y).sum();fp=np.logical_and(p,~y).sum()
    fn=np.logical_and(~p,y).sum();tn=np.logical_and(~p,~y).sum()
    div=lambda a,b: float(a/b) if b else float('nan')
    return dict(dice=div(2*tp,2*tp+fp+fn),iou=div(tp,tp+fp+fn),
                precision=div(tp,tp+fp),recall=div(tp,tp+fn),specificity=div(tn,tn+fp))
