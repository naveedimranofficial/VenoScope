"""VenoScope research reference implementation."""
