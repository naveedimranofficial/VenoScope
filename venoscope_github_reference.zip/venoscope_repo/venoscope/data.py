from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset

class NPZDataset(Dataset):
    """One subject-independent volume per NPZ; keys x (5,R,A,T), y (2,R,A,T)."""
    def __init__(self, directory):
        self.files=sorted(Path(directory).glob('*.npz'))
        if not self.files: raise ValueError(f"No NPZ files in {directory}")
    def __len__(self): return len(self.files)
    def __getitem__(self, idx):
        with np.load(self.files[idx],allow_pickle=False) as z:
            x=z['x'].astype(np.float32);y=z['y'].astype(np.float32)
        if x.ndim!=4 or y.ndim!=4 or x.shape[0]!=5 or y.shape[0]!=2 or x.shape[1:]!=y.shape[1:]:
            raise ValueError(f"Invalid shape: {self.files[idx]}")
        return torch.from_numpy(x),torch.from_numpy(y)
