"""Synthetic smoke-test data only; NOT clinical or paper experimental data."""
import argparse
from pathlib import Path
import numpy as np
from .features import build_features

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='data/demo');ap.add_argument('--n',type=int,default=4)
    args=ap.parse_args();p=Path(args.out);p.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(42);fs=12.0;T=64
    t=np.arange(T)/fs
    for i in range(args.n):
        rr,aa=np.ogrid[:16,:16]
        leg=((rr-8)**2/48+(aa-8)**2/40)<1
        pulse=((rr-8)**2/16+(aa-8)**2/16)<1
        ref=np.sin(2*np.pi*1.2*t)
        vol=rng.normal(0,0.3,(16,16,T))+pulse[...,None]*ref[None,None,:]
        x=build_features(vol,ref,fs,window=24)
        y=np.stack([np.broadcast_to(leg[...,None],(16,16,T)),np.broadcast_to(pulse[...,None],(16,16,T))]).astype(np.float32)
        np.savez_compressed(p/f'synthetic_{i:02d}.npz',x=x,y=y)
    print(f'Wrote {args.n} synthetic samples to {p}')
if __name__=='__main__':main()
