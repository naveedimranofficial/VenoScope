# VenoScope — Pulse-Synchronous 3D Segmentation (Reference Implementation)

**Research prototype; not a clinical DVT diagnostic system.**

This repository is a **new reference implementation** inspired by the VenoScope manuscript, *Pulse-Synchronous 3D U-Net DVT Risk Segmentation Using mmWave Radar and Wearables*. It is **not** the authors' recovered original experimental code, and the published metrics **cannot be reproduced** without the actual dataset, precise feature definitions, labels, splits, and training protocol.

## What is included

- Five-channel feature tensor: Energy, PSMF, DPFC, PSCM, TVI (explicitly documented *proxies*).
- 3D U-Net with base width 32 and two output logits: leg ROI and pulse-active mask.
- NPZ data loader, BCE + soft Dice training, independent evaluation.
- Synthetic-data generator for testing the software, **not** for validating research claims.
- Unit tests and command-line entry points.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
pytest -q
```

## Smoke test (synthetic only)

```bash
python -m venoscope.synthetic --out data/train --n 4
python -m venoscope.synthetic --out data/val --n 2
python -m venoscope.train --train data/train --val data/val --epochs 1 --base 4
python -m venoscope.evaluate --data data/val --checkpoint outputs/model.pt
```

The two generated folders use the same random seed and are **not independent**. They are suitable only for a software smoke test; do not report their metrics as research results.

## Real-data contract

One compressed `.npz` per subject or non-overlapping subject window, containing:

- `x`: float32 `(5, R, A, T)` in the channel order `[Energy, PSMF, DPFC, PSCM, TVI]`.
- `y`: float32 `(2, R, A, T)` with binary leg and pulse-active masks.

Place distinct subject IDs in `data/train`, `data/val`, `data/test`; never put windows from one subject in multiple partitions. Labels must come from a documented independent annotation protocol. Do not infer clinical thrombosis labels from pulse activity.

## Important limitations

The feature extraction in `venoscope/features.py` uses simplified, documented signal-processing proxies. Radar ADC ingestion, device-specific calibration, AoA reconstruction, complex-signal conventions, wearable synchronization, weak-label creation, physiology loss, and exploratory DVT scoring are **not** validated or implemented here. The model depth, output formulation, and training objective must be compared with the final paper before making any reproduction claim. AUROC is not reported because it requires a specified evaluation protocol and valid per-voxel probabilities/labels.

The paper's reported Dice/IoU/AUROC values are **not outputs from this repository**. Do not cite this code as reproducing them until the original protocol is implemented and independently tested.

## Release checklist

- [ ] Confirm manuscript version, channel definitions, and network dimensions.
- [ ] Replace proxies with verified implementation and unit tests.
- [ ] Obtain authorization and consent for sharing radar and wearable data.
- [ ] Document anonymization, licensing, annotation, subject splits, and data access.
- [ ] Validate reproducibility with independent evaluation and hardware specs.
- [ ] Add actual paper citation/DOI after publication.

## License

MIT (see `LICENSE`). No clinical use is authorized by this license.
