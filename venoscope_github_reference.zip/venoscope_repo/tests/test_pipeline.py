import numpy as np
import torch
from venoscope.features import build_features
from venoscope.model import VenoUNet
from venoscope.metrics import binary_metrics

def test_features():
    rng=np.random.default_rng(0)
    x=build_features(rng.normal(size=(8,8,64)),np.sin(2*np.pi*1.2*np.arange(64)/12),12,window=24)
    assert x.shape==(5,8,8,64)
    assert np.isfinite(x).all()

def test_model():
    m=VenoUNet(base=4)
    with torch.no_grad(): assert m(torch.randn(1,5,16,16,16)).shape==(1,2,16,16,16)

def test_metrics():
    assert binary_metrics([1,0,1],[1,0,1])['dice']==1.0
